# Telegram Digital Store Bot (Python + aiogram + SQLite + Stripe Checkout)

Bilingual Khmer/English Telegram digital store starter project for Windows. Includes:
- Product catalog with 3-column inline keyboard
- Khmer/English language selection
- SQLite products, orders, and user language preferences
- Stripe Checkout session creation
- Stripe webhook verification before marking an order paid
- Admin commands to add/list products, inspect orders, and deliver a digital code
- Stock tracking for digital codes

## Important payment notes
This starter integrates Stripe Checkout in **test mode**. Do not use real payments until your business and country are eligible, keys are configured securely, webhook delivery is tested, and you have reviewed the applicable laws and Stripe terms. Cambodia merchant eligibility may be limited. If you need KHQR/ABA/ACLEDA or another local gateway, you need that provider's official API credentials and documentation; replace `payments.py` with the provider's supported API.

Never share your bot token, Stripe secret key, webhook secret, customer data, or payment links publicly. This project does not store card details.

## 1. Create the Telegram bot
1. Open https://t.me/BotFather
2. Send `/newbot`, choose a name and username.
3. Copy the bot token into `.env` (never share it).
4. Get your Telegram numeric user ID using a trusted ID bot or your own bot logs, then set it in `ADMIN_IDS`.

## 2. Install on Windows
Install Python 3.11+ from https://www.python.org/downloads/ and enable **Add Python to PATH**.

Open Command Prompt in this folder:
```bat
py -m venv .venv
.venv\Scripts\activate
py -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```
Edit `.env` with Notepad and enter your values.

## 3. Configure Stripe TEST mode
1. Create/choose a Stripe account if eligible: https://dashboard.stripe.com/
2. Use test-mode API keys from Developers/API keys; put the secret key in `STRIPE_SECRET_KEY`.
3. Set `PUBLIC_BASE_URL` to a public HTTPS URL pointing to this computer, for example a secure tunnel URL. Stripe must be able to reach `/stripe/webhook`.
4. Create a webhook endpoint in Stripe test mode at:
   `https://YOUR_PUBLIC_BASE_URL/stripe/webhook`
   Subscribe to `checkout.session.completed` and `checkout.session.async_payment_succeeded`.
5. Copy the signing secret to `STRIPE_WEBHOOK_SECRET`.
6. Use only Stripe's test card details from its official documentation during testing. Never use real card data for test-mode verification.

The app's webhook server listens on port 8080. Keep the tunnel running while testing. Do not expose the Windows machine or webhook server without understanding firewall and security implications.

## 4. Run
```bat
.venv\Scripts\activate
python bot.py
```
Keep the terminal open. Closing it stops the bot. For 24/7 operation, use a properly secured server or Windows service.

## 5. Admin commands
- `/admin` — admin help
- `/addproduct` — interactive product creation
- `/products` — list products
- `/orders` — recent orders
- `/deliver ORDER_ID DIGITAL_CODE_OR_DELIVERY_TEXT` — mark an order delivered and send delivery text to buyer
- `/setstock PRODUCT_ID COUNT` — set stock count for products that use stock quantities
- `/disable PRODUCT_ID` / `/enable PRODUCT_ID`

For digital codes, the simplest safe setup is to create a product with stock > 0 and deliver a code manually after checking the paid order. Automatic code delivery is intentionally not enabled by default in the starter to avoid accidental disclosure or duplicate delivery. Set `AUTO_DELIVER_DIGITAL_CODES=true` only after implementing and testing your own code inventory workflow.

## Currency
Stripe Checkout expects a supported ISO currency. The demo defaults to `usd`. Do not set `KHR` unless the gateway account supports it. Prices are stored in minor units (e.g. USD $2.50 = 250 cents).

## Project layout
- `bot.py` — Telegram bot handlers and admin commands
- `db.py` — SQLite persistence
- `payments.py` — Stripe Checkout session + webhook verification
- `.env` — secrets (not included in the zip)
- `requirements.txt` — dependencies

This is a starter implementation, not a substitute for payment-provider onboarding, security review, tax advice, or production monitoring.
