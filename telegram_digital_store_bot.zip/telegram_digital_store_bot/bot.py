import asyncio
import os
import logging
from dotenv import load_dotenv
from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder

import db
from payments import create_checkout, verify_webhook

load_dotenv()
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("digital-store")

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
BOT_USERNAME = os.getenv("BOT_USERNAME", "")
ADMIN_IDS = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip().isdigit()}
CURRENCY = os.getenv("CURRENCY", "usd").lower()
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "https://replace-me.example")
WEBHOOK_HOST = os.getenv("WEBHOOK_HOST", "0.0.0.0")
WEBHOOK_PORT = int(os.getenv("WEBHOOK_PORT", "8080"))

if not BOT_TOKEN or BOT_TOKEN == "PASTE_BOTFATHER_TOKEN_HERE":
    raise SystemExit("Set BOT_TOKEN in .env first.")

bot = Bot(BOT_TOKEN)
dp = Dispatcher()

TEXT = {
    "km": {
        "welcome": "សូមស្វាគមន៍មកកាន់ {store} 🛍️\nជ្រើសរើសផលិតផលខាងក្រោម៖",
        "language": "ជ្រើសរើសភាសា / Choose language",
        "products": "🛍️ ផលិតផល",
        "stock": "ស្តុក",
        "buy": "💳 ទិញឥឡូវនេះ",
        "out": "អស់ស្តុក ឬផលិតផលមិនអាចទិញបានទេ។",
        "order": "Order #{id}\nផលិតផល៖ {name}\nតម្លៃ៖ {price}\nស្ថានភាព៖ រង់ចាំការទូទាត់។",
        "pay": "ចុចប៊ូតុងខាងក្រោមដើម្បីទូទាត់ដោយសុវត្ថិភាព។",
        "admin_only": "ពាក្យបញ្ជានេះសម្រាប់ Admin ប៉ុណ្ណោះ។",
        "admin_help": "Admin commands:\n/addproduct\n/products\n/orders\n/deliver ORDER_ID DELIVERY_TEXT\n/setstock PRODUCT_ID COUNT\n/disable PRODUCT_ID\n/enable PRODUCT_ID",
        "paid": "✅ ការទូទាត់បានបញ្ជាក់សម្រាប់ Order #{id}។ សូមរង់ចាំការផ្តល់ទំនិញ។",
        "delivery": "📦 ការផ្តល់ទំនិញសម្រាប់ Order #{id}:\n{text}",
        "not_paid": "Order នេះមិនទាន់បានបង់ប្រាក់ទេ។",
    },
    "en": {
        "welcome": "Welcome to {store} 🛍️\nChoose a product below:",
        "language": "Choose language / ជ្រើសរើសភាសា",
        "products": "🛍️ Products",
        "stock": "Stock",
        "buy": "💳 Buy now",
        "out": "This product is out of stock or unavailable.",
        "order": "Order #{id}\nProduct: {name}\nPrice: {price}\nStatus: awaiting payment.",
        "pay": "Tap below to pay securely.",
        "admin_only": "This command is for admins only.",
        "admin_help": "Admin commands:\n/addproduct\n/products\n/orders\n/deliver ORDER_ID DELIVERY_TEXT\n/setstock PRODUCT_ID COUNT\n/disable PRODUCT_ID\n/enable PRODUCT_ID",
        "paid": "✅ Payment confirmed for Order #{id}. Please wait for delivery.",
        "delivery": "📦 Delivery for Order #{id}:\n{text}",
        "not_paid": "This order has not been paid.",
    }
}

def money(minor, currency):
    currency = currency.upper()
    if currency in {"JPY", "KRW"}:
        return f"{minor} {currency}"
    return f"{minor / 100:.2f} {currency}"

async def lang(user_id):
    value = await db.get_language(user_id)
    return value if value in TEXT else "km"

def is_admin(user_id):
    return user_id in ADMIN_IDS

async def store_keyboard(language):
    products = await db.list_products()
    kb = InlineKeyboardBuilder()
    for p in products:
        name = p["name_km"] if language == "km" else p["name_en"]
        label = f'{p["icon"]} {name} · {money(p["price_minor"], p["currency"])}'
        kb.button(text=label[:60], callback_data=f'product:{p["id"]}')
    kb.adjust(3)
    kb.row(InlineKeyboardButton(text="🌐 ខ្មែរ / English", callback_data="language"))
    return kb.as_markup()

def language_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="🇰🇭 ខ្មែរ", callback_data="lang:km"),
        InlineKeyboardButton(text="🇬🇧 English", callback_data="lang:en"),
    ]])

@dp.message(CommandStart())
async def start(message: Message):
    language = await lang(message.from_user.id)
    await db.save_language(message.from_user.id, language)
    text = TEXT[language]["welcome"].format(store=os.getenv("STORE_NAME", "Digital Store"))
    await message.answer(text, reply_markup=await store_keyboard(language))

@dp.message(Command("language"))
async def language_command(message: Message):
    language = await lang(message.from_user.id)
    await message.answer(TEXT[language]["language"], reply_markup=language_keyboard())

@dp.callback_query(F.data == "language")
async def language_callback(callback: CallbackQuery):
    await callback.message.answer(TEXT[await lang(callback.from_user.id)]["language"], reply_markup=language_keyboard())
    await callback.answer()

@dp.callback_query(F.data.startswith("lang:"))
async def set_language(callback: CallbackQuery):
    language = callback.data.split(":", 1)[1]
    await db.save_language(callback.from_user.id, language)
    await callback.message.answer(TEXT[language]["welcome"].format(store=os.getenv("STORE_NAME", "Digital Store")),
                                  reply_markup=await store_keyboard(language))
    await callback.answer("Language updated")

@dp.callback_query(F.data.startswith("product:"))
async def product_details(callback: CallbackQuery):
    language = await lang(callback.from_user.id)
    product_id = int(callback.data.split(":", 1)[1])
    p = await db.get_product(product_id)
    if not p or not p["active"] or p["stock"] <= 0:
        await callback.answer(TEXT[language]["out"], show_alert=True)
        return
    name = p["name_km"] if language == "km" else p["name_en"]
    desc = p["description_km"] if language == "km" else p["description_en"]
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=TEXT[language]["buy"], callback_data=f"buy:{p['id']}")],
        [InlineKeyboardButton(text="⬅️ Store / ហាង", callback_data="back:store")]
    ])
    await callback.message.answer(
        f"{p['icon']} <b>{name}</b>\n{desc}\n💵 {money(p['price_minor'], p['currency'])}\n📦 {TEXT[language]['stock']}: {p['stock']}",
        reply_markup=kb, parse_mode="HTML"
    )
    await callback.answer()

@dp.callback_query(F.data == "back:store")
async def back_store(callback: CallbackQuery):
    language = await lang(callback.from_user.id)
    await callback.message.answer(TEXT[language]["products"], reply_markup=await store_keyboard(language))
    await callback.answer()

@dp.callback_query(F.data.startswith("buy:"))
async def buy_product(callback: CallbackQuery):
    language = await lang(callback.from_user.id)
    product_id = int(callback.data.split(":", 1)[1])
    p = await db.get_product(product_id)
    if not p or not p["active"] or p["stock"] <= 0:
        await callback.answer(TEXT[language]["out"], show_alert=True)
        return
    try:
        order_id = await db.create_order(callback.from_user.id, p)
        if order_id is None:
            await callback.answer(TEXT[language]["out"], show_alert=True)
            return
        session = create_checkout(order_id, p, callback.from_user.id, PUBLIC_BASE_URL)
        await db.attach_session(order_id, session.id)
        name = p["name_km"] if language == "km" else p["name_en"]
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="💳 Pay / ទូទាត់", url=session.url)]
        ])
        await callback.message.answer(
            TEXT[language]["order"].format(id=order_id, name=name, price=money(p["price_minor"], p["currency"])) +
            "\n\n" + TEXT[language]["pay"], reply_markup=kb
        )
        await callback.answer()
    except Exception as e:
        log.exception("Checkout creation failed")
        await callback.message.answer("Payment setup error. Please contact admin. / មានបញ្ហាប្រព័ន្ធទូទាត់ សូមទាក់ទង Admin។")
        await callback.answer()

@dp.message(Command("admin"))
async def admin_help(message: Message):
    language = await lang(message.from_user.id)
    if not is_admin(message.from_user.id):
        await message.answer(TEXT[language]["admin_only"])
        return
    await message.answer(TEXT[language]["admin_help"])

@dp.message(Command("addproduct"))
async def addproduct_help(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(TEXT[await lang(message.from_user.id)]["admin_only"])
        return
    await message.answer(
        "Send product details in one message, separated by | in this order:\n"
        "Name Khmer | Name English | Description Khmer | Description English | Price USD (e.g. 2.50) | Stock | Icon\n\n"
        "Example:\nGemini Pro 1 ខែ | Gemini Pro 1 month | សេវា ១ ខែ | One month service | 3.00 | 10 | ✨"
    )

@dp.message(F.text.contains("|"))
async def addproduct_submit(message: Message):
    if not is_admin(message.from_user.id):
        return
    parts = [x.strip() for x in message.text.split("|")]
    if len(parts) != 7:
        return
    try:
        name_km, name_en, desc_km, desc_en, price, stock, icon = parts
        price_minor = round(float(price) * 100)
        stock_int = int(stock)
        product_id = await db.add_product(name_km, name_en, desc_km, desc_en, price_minor, CURRENCY, stock_int, icon)
        await message.answer(f"✅ Added product ID {product_id}.")
    except Exception:
        await message.answer("Invalid product details. Check price and stock format.")

@dp.message(Command("products"))
async def admin_products(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(TEXT[await lang(message.from_user.id)]["admin_only"])
        return
    products = await db.list_products(active_only=False)
    if not products:
        await message.answer("No products.")
        return
    lines = [f'#{p["id"]} {p["icon"]} {p["name_en"]} — {money(p["price_minor"],p["currency"])} | stock={p["stock"]} | active={p["active"]}' for p in products]
    await message.answer("\n".join(lines))

@dp.message(Command("orders"))
async def admin_orders(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(TEXT[await lang(message.from_user.id)]["admin_only"])
        return
    rows = await db.recent_orders()
    if not rows:
        await message.answer("No orders yet.")
        return
    lines = [f"#{r[0]} user={r[1]} product={r[6]} total={money(r[2],r[3])} status={r[4]} at={r[5]}" for r in rows]
    await message.answer("\n".join(lines))

@dp.message(Command("deliver"))
async def admin_deliver(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(TEXT[await lang(message.from_user.id)]["admin_only"])
        return
    parts = message.text.split(maxsplit=2)
    if len(parts) < 3:
        await message.answer("Usage: /deliver ORDER_ID DELIVERY_TEXT")
        return
    try:
        order_id = int(parts[1])
    except ValueError:
        await message.answer("Order ID must be a number.")
        return
    user_id, status = await db.deliver_order(order_id, parts[2])
    if status == "not_found":
        await message.answer("Order not found.")
    elif status == "not_paid":
        await message.answer(TEXT[await lang(message.from_user.id)]["not_paid"])
    else:
        order = await db.get_order(order_id)
        await bot.send_message(user_id, TEXT[await lang(user_id)]["delivery"].format(id=order_id, text=parts[2]))
        await message.answer(f"Delivered Order #{order_id}.")

@dp.message(Command("setstock"))
async def admin_setstock(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer(TEXT[await lang(message.from_user.id)]["admin_only"])
        return
    parts = message.text.split()
    if len(parts) != 3:
        await message.answer("Usage: /setstock PRODUCT_ID COUNT")
        return
    try:
        ok = await db.set_stock(int(parts[1]), int(parts[2]))
        await message.answer("Updated." if ok else "Product not found.")
    except ValueError:
        await message.answer("IDs and count must be numbers.")

@dp.message(Command("disable"))
async def admin_disable(message: Message):
    await admin_toggle(message, False)

@dp.message(Command("enable"))
async def admin_enable(message: Message):
    await admin_toggle(message, True)

async def admin_toggle(message: Message, active: bool):
    if not is_admin(message.from_user.id):
        await message.answer(TEXT[await lang(message.from_user.id)]["admin_only"])
        return
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer("Usage: /enable PRODUCT_ID or /disable PRODUCT_ID")
        return
    ok = await db.set_active(int(parts[1]), active)
    await message.answer("Updated." if ok else "Product not found.")

async def health(request):
    return web.Response(text="Digital Store webhook server is running.")

async def success(request):
    return web.Response(text="Payment return page. Payment is confirmed only after the signed Stripe webhook is verified. You may return to Telegram.")

async def cancel(request):
    return web.Response(text="Payment canceled. You can return to Telegram and try again.")

async def stripe_webhook(request):
    payload = await request.read()
    signature = request.headers.get("Stripe-Signature", "")
    try:
        event = verify_webhook(payload, signature)
    except Exception as e:
        log.warning("Stripe webhook signature verification failed: %s", e)
        return web.Response(status=400, text="Invalid webhook signature")
    if event["type"] in ("checkout.session.completed", "checkout.session.async_payment_succeeded"):
        session = event["data"]["object"]
        if session.get("payment_status") == "paid":
            order_id, changed = await db.mark_paid(session["id"])
            if order_id and changed:
                order = await db.get_order(order_id)
                try:
                    await bot.send_message(order["user_id"], TEXT[await lang(order["user_id"])]["paid"].format(id=order_id))
                except Exception:
                    log.exception("Could not notify buyer")
    return web.Response(text="ok")

async def start_web_server():
    app = web.Application()
    app.router.add_get("/", health)
    app.router.add_get("/success", success)
    app.router.add_get("/cancel", cancel)
    app.router.add_post("/stripe/webhook", stripe_webhook)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, WEBHOOK_HOST, WEBHOOK_PORT)
    await site.start()
    log.info("Webhook server listening on %s:%s", WEBHOOK_HOST, WEBHOOK_PORT)
    return runner

async def main():
    await db.init_db()
    runner = await start_web_server()
    try:
        await dp.start_polling(bot)
    finally:
        await runner.cleanup()
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
