import os
import stripe

stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")

def create_checkout(order_id: int, product: dict, user_id: int, public_base_url: str):
    if not stripe.api_key or stripe.api_key.startswith("sk_test_replace"):
        raise RuntimeError("Set STRIPE_SECRET_KEY in .env before checkout.")
    base = public_base_url.rstrip("/")
    session = stripe.checkout.Session.create(
        mode="payment",
        success_url=f"{base}/success?order_id={order_id}",
        cancel_url=f"{base}/cancel?order_id={order_id}",
        client_reference_id=str(order_id),
        metadata={"order_id": str(order_id), "telegram_user_id": str(user_id), "product_id": str(product["id"])},
        line_items=[{
            "price_data": {
                "currency": product["currency"].lower(),
                "unit_amount": int(product["price_minor"]),
                "product_data": {"name": product["name_en"]},
            },
            "quantity": 1,
        }],
    )
    return session

def verify_webhook(payload: bytes, signature: str):
    secret = os.getenv("STRIPE_WEBHOOK_SECRET", "")
    if not secret or secret.startswith("whsec_replace"):
        raise RuntimeError("Set STRIPE_WEBHOOK_SECRET in .env.")
    return stripe.Webhook.construct_event(payload, signature, secret)
