import aiosqlite
from pathlib import Path
from typing import Optional

DB_PATH = Path(__file__).with_name("store.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    language TEXT NOT NULL DEFAULT 'km'
);
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name_km TEXT NOT NULL,
    name_en TEXT NOT NULL,
    description_km TEXT NOT NULL DEFAULT '',
    description_en TEXT NOT NULL DEFAULT '',
    price_minor INTEGER NOT NULL CHECK(price_minor >= 0),
    currency TEXT NOT NULL DEFAULT 'usd',
    stock INTEGER NOT NULL DEFAULT 0,
    icon TEXT NOT NULL DEFAULT '🛍️',
    active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    amount_minor INTEGER NOT NULL,
    currency TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    stripe_session_id TEXT UNIQUE,
    delivery_text TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    paid_at TEXT,
    delivered_at TEXT,
    FOREIGN KEY(product_id) REFERENCES products(id)
);
"""

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(SCHEMA)
        await db.commit()
        cur = await db.execute("SELECT COUNT(*) FROM products")
        count = (await cur.fetchone())[0]
        if count == 0:
            seed = [
                ("Gemini Pro 1 month", "Gemini Pro 1 month", "សេវាឌីជីថល ១ ខែ", "Digital service for 1 month", 300, "usd", 10, "✨", 1),
                ("Canva Pro 1 month", "Canva Pro 1 month", "សេវាឌីជីថល ១ ខែ", "Digital service for 1 month", 250, "usd", 10, "🎨", 1),
                ("VPN 1 month", "VPN 1 month", "សេវា VPN ១ ខែ", "VPN service for 1 month", 200, "usd", 10, "🔐", 1),
            ]
            await db.executemany(
                """INSERT INTO products
                (name_km,name_en,description_km,description_en,price_minor,currency,stock,icon,active)
                VALUES (?,?,?,?,?,?,?,?,?)""", seed
            )
            await db.commit()

async def save_language(user_id: int, language: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO users(user_id, language) VALUES(?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET language=excluded.language",
            (user_id, language)
        )
        await db.commit()

async def get_language(user_id: int) -> str:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT language FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        return row[0] if row else "km"

async def list_products(active_only=True):
    async with aiosqlite.connect(DB_PATH) as db:
        query = "SELECT id,name_km,name_en,description_km,description_en,price_minor,currency,stock,icon,active FROM products"
        if active_only:
            query += " WHERE active=1"
        query += " ORDER BY id"
        cur = await db.execute(query)
        rows = await cur.fetchall()
        return [dict(zip(["id","name_km","name_en","description_km","description_en","price_minor","currency","stock","icon","active"], r)) for r in rows]

async def get_product(product_id: int):
    products = await list_products(active_only=False)
    return next((p for p in products if p["id"] == product_id), None)

async def add_product(name_km, name_en, desc_km, desc_en, price_minor, currency, stock, icon="🛍️"):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """INSERT INTO products(name_km,name_en,description_km,description_en,price_minor,currency,stock,icon)
            VALUES(?,?,?,?,?,?,?,?)""",
            (name_km,name_en,desc_km,desc_en,price_minor,currency.lower(),stock,icon)
        )
        await db.commit()
        return cur.lastrowid

async def create_order(user_id: int, product: dict):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute("SELECT stock,active FROM products WHERE id=?", (product["id"],))
        row = await cur.fetchone()
        if not row or not row[1] or row[0] <= 0:
            await db.rollback()
            return None
        await db.execute(
            "INSERT INTO orders(user_id,product_id,amount_minor,currency,status) VALUES(?,?,?,?, 'pending')",
            (user_id, product["id"], product["price_minor"], product["currency"])
        )
        order_id = (await db.execute("SELECT last_insert_rowid()")).fetchone()
        order_id = (await order_id)[0]
        await db.commit()
        return order_id

async def attach_session(order_id: int, session_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE orders SET stripe_session_id=? WHERE id=? AND status='pending'", (session_id, order_id))
        await db.commit()

async def get_order(order_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """SELECT o.id,o.user_id,o.product_id,o.amount_minor,o.currency,o.status,o.stripe_session_id,
            o.delivery_text,o.created_at,o.paid_at,o.delivered_at,p.name_km,p.name_en
            FROM orders o JOIN products p ON p.id=o.product_id WHERE o.id=?""", (order_id,)
        )
        row = await cur.fetchone()
        keys = ["id","user_id","product_id","amount_minor","currency","status","stripe_session_id",
                "delivery_text","created_at","paid_at","delivered_at","name_km","name_en"]
        return dict(zip(keys, row)) if row else None

async def recent_orders(limit=20):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            """SELECT o.id,o.user_id,o.amount_minor,o.currency,o.status,o.created_at,p.name_en
            FROM orders o JOIN products p ON p.id=o.product_id ORDER BY o.id DESC LIMIT ?""", (limit,)
        )
        return await cur.fetchall()

async def mark_paid(session_id: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("BEGIN IMMEDIATE")
        cur = await db.execute("SELECT id,product_id,status FROM orders WHERE stripe_session_id=?", (session_id,))
        row = await cur.fetchone()
        if not row:
            await db.rollback()
            return None, False
        order_id, product_id, status = row
        if status in ("paid", "delivered"):
            await db.commit()
            return order_id, False
        if status != "pending":
            await db.rollback()
            return order_id, False
        cur = await db.execute("SELECT stock FROM products WHERE id=?", (product_id,))
        stock = (await cur.fetchone())[0]
        if stock > 0:
            await db.execute("UPDATE products SET stock=stock-1 WHERE id=?", (product_id,))
        await db.execute("UPDATE orders SET status='paid',paid_at=CURRENT_TIMESTAMP WHERE id=?", (order_id,))
        await db.commit()
        return order_id, True

async def deliver_order(order_id: int, delivery_text: str):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id,status FROM orders WHERE id=?", (order_id,))
        row = await cur.fetchone()
        if not row:
            return None, "not_found"
        user_id, status = row
        if status not in ("paid", "delivered"):
            return None, "not_paid"
        await db.execute(
            "UPDATE orders SET status='delivered',delivery_text=?,delivered_at=CURRENT_TIMESTAMP WHERE id=?",
            (delivery_text, order_id)
        )
        await db.commit()
        return user_id, "ok"

async def set_stock(product_id: int, stock: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("UPDATE products SET stock=? WHERE id=?", (stock, product_id))
        await db.commit()
        return cur.rowcount > 0

async def set_active(product_id: int, active: bool):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("UPDATE products SET active=? WHERE id=?", (1 if active else 0, product_id))
        await db.commit()
        return cur.rowcount > 0
